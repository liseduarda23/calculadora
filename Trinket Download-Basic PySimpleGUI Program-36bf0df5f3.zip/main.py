import PySimpleGUI as sg

sg.theme("DarkPurple6")

layout = [ 
    [sg.Input('', key='-DISPLAY-', size=(15, 1))],
    [sg.B('1'),sg.B('2'),sg.B('3'),sg.B('/')],
    [sg.B('4'),sg.B('5'),sg.B('6'),sg.B('*')],
    [sg.B('7'),sg.B('8'),sg.B('9'),sg.B('-')],
    [sg.B('.'),sg.B('0'),sg.B('='),sg.B('+')],   
]

janela = sg.Window('Calculadora', layout = layout, font='monospace 18')

while True:
    event, values = janela.read()

    if event == sg.WIN_CLOSED:
        break
